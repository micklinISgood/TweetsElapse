
import java.net.URI;
 

/**
 * ChatBot
 * @author Jiji_Sasidharan
 */
public class Client {
 
    /**
     * main
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        final ChatClientEndpoint clientEndPoint = new ChatClientEndpoint(new URI("ws://localhost:8080/elapse/conn"));
        clientEndPoint.addMessageHandler(new ChatClientEndpoint.MessageHandler() {
                    public void handleMessage(String message) {
                        
                    }
                });
 
        while (true) {
            clientEndPoint.sendMessage("test");
            Thread.sleep(30000);
        }
    }
 
    /**
     * Create a json representation.
     * 
     * @param message
     * @return
     */
 
}